package com.example.patientmanagement.service;

import com.example.patientmanagement.model.Patient;
import com.example.patientmanagement.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    private final PatientRepository repo;

    public PatientService(PatientRepository repo) {
        this.repo = repo;
    }

    public List<Patient> getAll() {
        return repo.findAll();
    }

    public Optional<Patient> getById(Long id) {
        return repo.findById(id);
    }

    public Patient save(Patient patient) {
        return repo.save(patient);
    }

    public Patient update(Long id, Patient patient) {
        patient.setId(id);
        return repo.save(patient);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
