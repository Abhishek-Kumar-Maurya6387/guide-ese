package com.example.patientmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
